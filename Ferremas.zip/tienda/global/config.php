<?php
define("KEY","integracion");
define("COD","AES-128-ECB");

define("SERVIDOR","localhost");
define("USUARIO","root");
define("PASSWORD","");
define("BD","tienda");

?>